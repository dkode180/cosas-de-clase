﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej6bHilos
{
    internal class MyTimer
    {
        public static bool running;
        public static readonly object l = new object();
        public int Interval { set; get; }
        public delegate void MyDelegate();
        public static MyDelegate del;//Hago un delegado para recoger la funcion que se pasa en el constructor y poder llamarla luego en TimerLoop

        public MyTimer(MyDelegate f1)
        {
            del = f1;
            Thread hilo = new Thread(TimerLoop);
            hilo.Start();
        }
        public void Pause()
        {
            if (running)
            {
                running = false;
            }
        }
        public void Run()
        {
            if (!running)
            {
                lock (l)
                {
                    running = true;
                    Monitor.Pulse(l);
                } 
            }

        }

        public void TimerLoop()
        {
            while (true)
            {
                lock (l)
                {
                    if (!running)
                    {
                        Monitor.Wait(l);
                    }
                }
                Thread.Sleep(Interval);
                lock (l)
                {
                    del();
                }

            }
        }
    }
}
